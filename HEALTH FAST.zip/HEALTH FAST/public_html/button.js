document.addEventListener('DOMContentLoaded', () => {
  const currentLang = document.querySelector('.current-lang');
  const dropdownMenu = document.querySelector('.language-select > ul > li > ul');
  let isOpen = false;

  if (currentLang && dropdownMenu) {
      // Toggle menu on current-lang click
      currentLang.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          isOpen = !isOpen;
          dropdownMenu.style.display = isOpen ? 'block' : 'none';
      });

      // Keep menu open when clicking inside dropdown
      dropdownMenu.addEventListener('click', (e) => {
          e.stopPropagation();
      });

      // Close menu when clicking outside
      document.addEventListener('click', (e) => {
          if (!currentLang.contains(e.target) && !dropdownMenu.contains(e.target)) {
              isOpen = false;
              dropdownMenu.style.display = 'none';
          }
      });

      // Handle language selection
      const languageLinks = dropdownMenu.querySelectorAll('a');
      languageLinks.forEach(link => {
          link.addEventListener('click', (e) => {
              e.preventDefault();
              const href = link.getAttribute('href');
              if (href) {
                  window.location.href = href;
              }
          });
      });
  }
});