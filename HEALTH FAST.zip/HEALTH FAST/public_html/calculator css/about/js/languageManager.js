import ru from '../translations/ru.js'
import en from '../translations/en.js'

export class LanguageManager {
  constructor() {
    this.translations = { ru, en }
    this.currentLang = localStorage.getItem('language') || 'ru'
  }

  setLanguage(lang) {
    this.currentLang = lang
    localStorage.setItem('language', lang)
    this.updateContent()
  }

  toggleLanguage() {
    const newLang = this.currentLang === 'ru' ? 'en' : 'ru'
    this.setLanguage(newLang)
  }

  getText(key) {
    return key.split('.').reduce((obj, k) => obj?.[k], this.translations[this.currentLang])
  }

  updateContent() {
    // Update header
    document.querySelector('.header h1').textContent = this.getText('header.title')
    document.querySelector('.header p').textContent = this.getText('header.subtitle')

    // Update features
    const features = document.querySelectorAll('.feature-card')
    features[0].querySelector('h3').textContent = this.getText('features.quickCalc.title')
    features[0].querySelector('p').textContent = this.getText('features.quickCalc.description')
    features[1].querySelector('h3').textContent = this.getText('features.services.title')
    features[1].querySelector('p').textContent = this.getText('features.services.description')
    features[2].querySelector('h3').textContent = this.getText('features.reliability.title')
    features[2].querySelector('p').textContent = this.getText('features.reliability.description')

    // Update how it works section
    document.querySelector('.how-it-works h2').textContent = this.getText('howItWorks.title')
    const steps = document.querySelectorAll('.steps li')
    steps[0].innerHTML = `<strong>${this.getText('howItWorks.steps.dataInput.title')}:</strong> ${this.getText('howItWorks.steps.dataInput.description')}`
    steps[1].innerHTML = `<strong>${this.getText('howItWorks.steps.calculation.title')}:</strong> ${this.getText('howItWorks.steps.calculation.description')}`
    steps[2].innerHTML = `<strong>${this.getText('howItWorks.steps.recommendations.title')}:</strong> ${this.getText('howItWorks.steps.recommendations.description')}`

    document.querySelector('.how-it-works > p').textContent = this.getText('howItWorks.conclusion')
    document.querySelector('.cta-button').textContent = this.getText('howItWorks.button')
  }
}