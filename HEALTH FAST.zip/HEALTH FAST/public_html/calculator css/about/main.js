import './style.css'
import { LanguageManager } from './js/languageManager.js'

// Initialize language manager
const langManager = new LanguageManager()

// Create and render the main content
function renderContent() {
  document.querySelector('#app').innerHTML = `
    <button class="language-toggle" id="langToggle">
      ${langManager.currentLang === 'ru' ? 'EN' : 'RU'}
    </button>
    <div class="container">
      <header class="header">
        <h1></h1>
        <p></p>
      </header>

      <div class="features">
        <div class="feature-card">
          <h3></h3>
          <p></p>
        </div>

        <div class="feature-card">
          <h3></h3>
          <p></p>
        </div>

        <div class="feature-card">
          <h3></h3>
          <p></p>
        </div>
      </div>

      <section class="how-it-works">
        <h2></h2>
        <ul class="steps">
          <li></li>
          <li></li>
          <li></li>
        </ul>
        
        <p></p>
        
        <button class="cta-button" id="calculate-btn"></button>
      </section>
    </div>
  `

  // Update content with current language
  langManager.updateContent()

  // Add event listeners
  document.querySelector('#langToggle').addEventListener('click', () => {
    langManager.toggleLanguage()
    document.querySelector('#langToggle').textContent = langManager.currentLang === 'ru' ? 'EN' : 'RU'
  })

  document.querySelector('#calculate-btn').addEventListener('click', () => {
    console.log('Calculate button clicked')
  })
}

// Initial render
renderContent()