export default {
  header: {
    title: 'About Us',
    subtitle: 'Perfect Macro Balance for Your Health and Goals'
  },
  features: {
    quickCalc: {
      title: 'Quick Calculator',
      description: 'Calculate Your Macro Norm in 60 Seconds Using Scientific Formulas.'
    },
    services: {
      title: 'Services',
      description: 'Free Workouts and Diet Plans.'
    },
    reliability: {
      title: 'Reliability',
      description: 'Based on Scientific Research'
    }
  },
  howItWorks: {
    title: 'How it works:',
    steps: {
      dataInput: {
        title: 'Data Input',
        description: 'Enter your age, weight, height, physical activity level, and goal.'
      },
      calculation: {
        title: 'Macro Calculation',
        description: 'We\'ll precisely determine your daily norm of calories, proteins, fats, and carbohydrates.'
      },
      recommendations: {
        title: 'Ready Recommendations',
        description: 'Based on calculations, you\'ll receive a free meal and workout plan tailored to your parameters and goal.'
      }
    },
    conclusion: 'No more guessing how to balance your nutrition or which exercises to choose. Simply enter your data, get recommendations, and start your journey to a healthy and active lifestyle right now!',
    button: 'CALCULATE MACROS'
  }
}