// Calculator core logic
const ACTIVITY_MULTIPLIERS = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    active: 1.725,
    'very-active': 1.9
};

const GOAL_MULTIPLIERS = {
    lose: 0.85,
    maintain: 1,
    gain: 1.15
};

class MacroCalculator {
    static calculateBMR(weight, height, age) {
        // Mifflin-St Jeor Formula
        return 10 * weight + 6.25 * height - 5 * age + 5;
    }

    static calculateTDEE(bmr, activityLevel) {
        return Math.round(bmr * ACTIVITY_MULTIPLIERS[activityLevel]);
    }

    static calculateMacros(tdee, goal) {
        const targetCalories = Math.round(tdee * GOAL_MULTIPLIERS[goal]);
        
        let proteinRatio, fatRatio;
        switch(goal) {
            case 'lose':
                proteinRatio = 0.4;
                fatRatio = 0.35;
                break;
            case 'gain':
                proteinRatio = 0.3;
                fatRatio = 0.3;
                break;
            default:
                proteinRatio = 0.35;
                fatRatio = 0.3;
        }
        
        const carbRatio = 1 - proteinRatio - fatRatio;
        
        return {
            calories: targetCalories,
            protein: Math.round((targetCalories * proteinRatio) / 4),
            fats: Math.round((targetCalories * fatRatio) / 9),
            carbs: Math.round((targetCalories * carbRatio) / 4)
        };
    }
}


