// Form submission and navigation handling
document.getElementById('calculatorForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = {
        age: document.getElementById('age').value,
        weight: document.getElementById('weight').value,
        height: document.getElementById('height').value,
        activity: document.getElementById('activity').value,
        goal: document.getElementById('goal').value
    };
    
    const errors = validateForm(formData);
    
    if (errors.length > 0) {
        errors.forEach(field => {
            const element = document.getElementById(field);
            element.classList.add('error');
            setTimeout(() => element.classList.remove('error'), 500);
        });
        return;
    }
    
    // Calculate results
    const bmr = MacroCalculator.calculateBMR(
        Number(formData.weight),
        Number(formData.height),
        Number(formData.age)    
    );
    
    const tdee = MacroCalculator.calculateTDEE(bmr, formData.activity);
    const results = MacroCalculator.calculateMacros(tdee, formData.goal);
    
    // Store results in localStorage
    localStorage.setItem('macroResults', JSON.stringify(results));
    
    // Navigate to results page
    window.location.href = 'results.html';
});