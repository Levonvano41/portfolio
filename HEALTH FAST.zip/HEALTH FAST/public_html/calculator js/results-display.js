// Results page display logic
document.addEventListener('DOMContentLoaded', function() {
    const results = JSON.parse(localStorage.getItem('macroResults'));
    
    if (!results) {
        window.location.href = 'index.html';
        return;
    }
    
    // Display results
    document.getElementById('calories').textContent = results.calories;
    document.getElementById('protein').textContent = `${results.protein}г`;
    document.getElementById('fats').textContent = `${results.fats}г`;
    document.getElementById('carbs').textContent = `${results.carbs}г`;
    
    // Clear storage after displaying
    localStorage.removeItem('macroResults');
});