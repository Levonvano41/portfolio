// Form validation functions
const validators = {
    age: (value) => {
        const age = Number(value);
        return age >= 15 && age <= 100;
    },
    
    weight: (value) => {
        const weight = Number(value);
        return weight >= 30 && weight <= 300;
    },
    
    height: (value) => {
        const height = Number(value);
        return height >= 100 && height <= 250;
    },
    
    activity: (value) => {
        const validActivities = ['sedentary', 'light', 'moderate', 'active', 'very-active'];
        return validActivities.includes(value);
    },
    
    goal: (value) => {
        const validGoals = ['lose', 'maintain', 'gain'];
        return validGoals.includes(value);
    }
};

function validateForm(formData) {
    const errors = [];
    
    for (const [field, value] of Object.entries(formData)) {
        if (!validators[field](value)) {
            errors.push(field);
        }
    }
    
    return errors;
}